﻿namespace CycleRace
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.cycleTrack = new System.Windows.Forms.PictureBox();
            this.racer1 = new System.Windows.Forms.PictureBox();
            this.racer2 = new System.Windows.Forms.PictureBox();
            this.racer3 = new System.Windows.Forms.PictureBox();
            this.racer4 = new System.Windows.Forms.PictureBox();
            this.btnRace = new System.Windows.Forms.Button();
            this.buttonBets = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.MinimumBet = new System.Windows.Forms.Label();
            this.labelAlsBet = new System.Windows.Forms.Label();
            this.labelBobsBet = new System.Windows.Forms.Label();
            this.labelJoesBet = new System.Windows.Forms.Label();
            this.numericUpDownCar = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownBets = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButtonKamal = new System.Windows.Forms.RadioButton();
            this.radioButtonSunny = new System.Windows.Forms.RadioButton();
            this.radioButtonBikram = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cycleTrack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer4)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBets)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.racer4);
            this.panel1.Controls.Add(this.racer3);
            this.panel1.Controls.Add(this.racer2);
            this.panel1.Controls.Add(this.racer1);
            this.panel1.Controls.Add(this.cycleTrack);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(900, 400);
            this.panel1.TabIndex = 0;
            // 
            // cycleTrack
            // 
            this.cycleTrack.Image = global::CycleRace.Properties.Resources.track_3_copy;
            this.cycleTrack.Location = new System.Drawing.Point(-2, -2);
            this.cycleTrack.Name = "cycleTrack";
            this.cycleTrack.Size = new System.Drawing.Size(900, 400);
            this.cycleTrack.TabIndex = 1;
            this.cycleTrack.TabStop = false;
            // 
            // racer1
            // 
            this.racer1.Image = global::CycleRace.Properties.Resources._1___Copy2;
            this.racer1.Location = new System.Drawing.Point(39, 57);
            this.racer1.Name = "racer1";
            this.racer1.Size = new System.Drawing.Size(100, 50);
            this.racer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.racer1.TabIndex = 2;
            this.racer1.TabStop = false;
            // 
            // racer2
            // 
            this.racer2.Image = global::CycleRace.Properties.Resources._1___Copy2;
            this.racer2.Location = new System.Drawing.Point(39, 147);
            this.racer2.Name = "racer2";
            this.racer2.Size = new System.Drawing.Size(100, 50);
            this.racer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.racer2.TabIndex = 3;
            this.racer2.TabStop = false;
            this.racer2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // racer3
            // 
            this.racer3.Image = global::CycleRace.Properties.Resources._1___Copy2;
            this.racer3.Location = new System.Drawing.Point(39, 246);
            this.racer3.Name = "racer3";
            this.racer3.Size = new System.Drawing.Size(100, 50);
            this.racer3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.racer3.TabIndex = 4;
            this.racer3.TabStop = false;
            // 
            // racer4
            // 
            this.racer4.Image = global::CycleRace.Properties.Resources._1___Copy2;
            this.racer4.Location = new System.Drawing.Point(39, 332);
            this.racer4.Name = "racer4";
            this.racer4.Size = new System.Drawing.Size(100, 50);
            this.racer4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.racer4.TabIndex = 5;
            this.racer4.TabStop = false;
            // 
            // btnRace
            // 
            this.btnRace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRace.Location = new System.Drawing.Point(574, 410);
            this.btnRace.Name = "btnRace";
            this.btnRace.Size = new System.Drawing.Size(92, 32);
            this.btnRace.TabIndex = 38;
            this.btnRace.Text = "Race!";
            this.btnRace.UseVisualStyleBackColor = true;
            this.btnRace.Click += new System.EventHandler(this.btnRace_Click);
            // 
            // buttonBets
            // 
            this.buttonBets.Location = new System.Drawing.Point(128, 406);
            this.buttonBets.Name = "buttonBets";
            this.buttonBets.Size = new System.Drawing.Size(112, 42);
            this.buttonBets.TabIndex = 37;
            this.buttonBets.Text = "Place Bet";
            this.buttonBets.UseVisualStyleBackColor = true;
            this.buttonBets.Click += new System.EventHandler(this.buttonBets_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.MinimumBet);
            this.groupBox1.Controls.Add(this.labelAlsBet);
            this.groupBox1.Controls.Add(this.labelBobsBet);
            this.groupBox1.Controls.Add(this.labelJoesBet);
            this.groupBox1.Controls.Add(this.numericUpDownCar);
            this.groupBox1.Controls.Add(this.numericUpDownBets);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.radioButtonKamal);
            this.groupBox1.Controls.Add(this.radioButtonSunny);
            this.groupBox1.Controls.Add(this.radioButtonBikram);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(14, 457);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(862, 128);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Betting System";
            // 
            // MinimumBet
            // 
            this.MinimumBet.AutoSize = true;
            this.MinimumBet.Location = new System.Drawing.Point(243, 38);
            this.MinimumBet.Name = "MinimumBet";
            this.MinimumBet.Size = new System.Drawing.Size(78, 13);
            this.MinimumBet.TabIndex = 26;
            this.MinimumBet.Text = "Minimum Bet";
            // 
            // labelAlsBet
            // 
            this.labelAlsBet.AutoSize = true;
            this.labelAlsBet.BackColor = System.Drawing.Color.White;
            this.labelAlsBet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelAlsBet.Location = new System.Drawing.Point(529, 106);
            this.labelAlsBet.Name = "labelAlsBet";
            this.labelAlsBet.Size = new System.Drawing.Size(145, 15);
            this.labelAlsBet.TabIndex = 25;
            this.labelAlsBet.Text = "Kamal hasn\'t placed bet";
            // 
            // labelBobsBet
            // 
            this.labelBobsBet.AutoSize = true;
            this.labelBobsBet.BackColor = System.Drawing.Color.White;
            this.labelBobsBet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelBobsBet.Location = new System.Drawing.Point(529, 66);
            this.labelBobsBet.Name = "labelBobsBet";
            this.labelBobsBet.Size = new System.Drawing.Size(146, 15);
            this.labelBobsBet.TabIndex = 24;
            this.labelBobsBet.Text = "Sunny hasn\'t placed bet";
            // 
            // labelJoesBet
            // 
            this.labelJoesBet.AutoSize = true;
            this.labelJoesBet.BackColor = System.Drawing.Color.White;
            this.labelJoesBet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelJoesBet.Location = new System.Drawing.Point(529, 28);
            this.labelJoesBet.Name = "labelJoesBet";
            this.labelJoesBet.Size = new System.Drawing.Size(149, 15);
            this.labelJoesBet.TabIndex = 23;
            this.labelJoesBet.Text = "Bikram hasn\'t placed bet";
            // 
            // numericUpDownCar
            // 
            this.numericUpDownCar.Location = new System.Drawing.Point(412, 74);
            this.numericUpDownCar.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDownCar.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCar.Name = "numericUpDownCar";
            this.numericUpDownCar.Size = new System.Drawing.Size(44, 20);
            this.numericUpDownCar.TabIndex = 22;
            this.numericUpDownCar.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownBets
            // 
            this.numericUpDownBets.Location = new System.Drawing.Point(412, 36);
            this.numericUpDownBets.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownBets.Name = "numericUpDownBets";
            this.numericUpDownBets.Size = new System.Drawing.Size(44, 20);
            this.numericUpDownBets.TabIndex = 21;
            this.numericUpDownBets.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(387, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = " #";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(392, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "$";
            // 
            // radioButtonKamal
            // 
            this.radioButtonKamal.AutoSize = true;
            this.radioButtonKamal.Location = new System.Drawing.Point(34, 106);
            this.radioButtonKamal.Name = "radioButtonKamal";
            this.radioButtonKamal.Size = new System.Drawing.Size(59, 17);
            this.radioButtonKamal.TabIndex = 2;
            this.radioButtonKamal.TabStop = true;
            this.radioButtonKamal.Text = "Kamal";
            this.radioButtonKamal.UseVisualStyleBackColor = true;
            // 
            // radioButtonSunny
            // 
            this.radioButtonSunny.AutoSize = true;
            this.radioButtonSunny.Location = new System.Drawing.Point(34, 64);
            this.radioButtonSunny.Name = "radioButtonSunny";
            this.radioButtonSunny.Size = new System.Drawing.Size(60, 17);
            this.radioButtonSunny.TabIndex = 1;
            this.radioButtonSunny.TabStop = true;
            this.radioButtonSunny.Text = "Sunny";
            this.radioButtonSunny.UseVisualStyleBackColor = true;
            // 
            // radioButtonBikram
            // 
            this.radioButtonBikram.AutoSize = true;
            this.radioButtonBikram.Location = new System.Drawing.Point(34, 28);
            this.radioButtonBikram.Name = "radioButtonBikram";
            this.radioButtonBikram.Size = new System.Drawing.Size(63, 17);
            this.radioButtonBikram.TabIndex = 0;
            this.radioButtonBikram.TabStop = true;
            this.radioButtonBikram.Text = "Bikram";
            this.radioButtonBikram.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 604);
            this.Controls.Add(this.btnRace);
            this.Controls.Add(this.buttonBets);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cycleTrack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.racer4)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBets)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox cycleTrack;
        private System.Windows.Forms.PictureBox racer4;
        private System.Windows.Forms.PictureBox racer3;
        private System.Windows.Forms.PictureBox racer2;
        private System.Windows.Forms.PictureBox racer1;
        private System.Windows.Forms.Button btnRace;
        private System.Windows.Forms.Button buttonBets;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label MinimumBet;
        private System.Windows.Forms.Label labelAlsBet;
        private System.Windows.Forms.Label labelBobsBet;
        private System.Windows.Forms.Label labelJoesBet;
        private System.Windows.Forms.NumericUpDown numericUpDownCar;
        private System.Windows.Forms.NumericUpDown numericUpDownBets;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButtonKamal;
        private System.Windows.Forms.RadioButton radioButtonSunny;
        private System.Windows.Forms.RadioButton radioButtonBikram;
    }
}

